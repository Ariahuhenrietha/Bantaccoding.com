import psycopg2

def connect_db():
    return psycopg2.connect(
        dbname="todolist",
        user="postgres",
        password="chinwe",
        host="localhost"
    )

def add_task(task):
    conn = connect_db()
    cur = conn.cursor()
    cur.execute("INSERT INTO tasks (task) VALUES (%s)", (task,))
    conn.commit()
    cur.close()
    conn.close()

def list_tasks():
    conn = connect_db()
    cur = conn.cursor()
    cur.execute("SELECT id, task, status FROM tasks")
    tasks = cur.fetchall()
    cur.close()
    conn.close()
    return tasks

def update_task(task_id, status):
    conn = connect_db()
    cur = conn.cursor()
    cur.execute("UPDATE tasks SET status = %s WHERE id = %s", (status, task_id))
    conn.commit()
    cur.close()
    conn.close()

def delete_task(task_id):
    conn = connect_db()
    cur = conn.cursor()
    cur.execute("DELETE FROM tasks WHERE id = %s", (task_id,))
    conn.commit()
    cur.close()
    conn.close()

# Example usage
if __name__ == "__main__":
    add_task("Buy groceries")
    add_task("Walk the dog")
    print("Tasks after adding:")
    print(list_tasks())
    
    update_task(1, True)
    print("Tasks after updating task 1:")
    print(list_tasks())
    
    delete_task(2)
    print("Tasks after deleting task 2:")
    print(list_tasks())
