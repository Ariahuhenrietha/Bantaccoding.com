import psycopg2
import re

def connect_db():
    return psycopg2.connect(
        dbname="babynamesdb",
        user="postgres",
        password="chinwe",  # Replace with your actual PostgreSQL password
        host="localhost"
    )

def save_babynames(names):
    conn = connect_db()
    cur = conn.cursor()
    for name in names:
        cur.execute("INSERT INTO babynames (name) VALUES (%s)", (name,))
    conn.commit()
    cur.close()
    conn.close()

def extract_names_from_file(file_path):
    with open(file_path, 'r') as file:
        text = file.read()
    names = re.findall(r'\b[A-Z][a-z]*\b', text)
    return names

# File path to the text file containing baby names
file_path = "C:/Users/User/Desktop/PYTHON PROGRAMS/baby2008.html"

# Extract names from the file
names = extract_names_from_file(file_path)
print("Extracted names:", names)

# Save names to PostgreSQL
save_babynames(names)
