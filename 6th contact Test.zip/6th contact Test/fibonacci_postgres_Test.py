import psycopg2

# Database connection parameters
db_params = {
    'dbname': 'postgres',       # Your database name
    'user': 'postgres',         # Your username
    'password': 'chinwe', # Your password (replace 'your_password' with the actual password)
    'host': 'localhost',        # Your host
    'port': '5432'              # Your port
}

def connect_db():
    conn = psycopg2.connect(**db_params)
    return conn

def create_todo_table():
    conn = connect_db()
    cursor = conn.cursor()
    cursor.execute('''CREATE TABLE IF NOT EXISTS todos (
                        id SERIAL PRIMARY KEY,
                        task TEXT NOT NULL,
                        status BOOLEAN NOT NULL DEFAULT FALSE)''')
    conn.commit()
    cursor.close()
    conn.close()

def add_todo(task):
    conn = connect_db()
    cursor = conn.cursor()
    cursor.execute('INSERT INTO todos (task, status) VALUES (%s, %s)', (task, False))
    conn.commit()
    cursor.close()
    conn.close()

def get_todos():
    conn = connect_db()
    cursor = conn.cursor()
    cursor.execute('SELECT * FROM todos')
    todos = cursor.fetchall()
    cursor.close()
    conn.close()
    return todos

def update_todo_status(todo_id, status):
    conn = connect_db()
    cursor = conn.cursor()
    cursor.execute('UPDATE todos SET status = %s WHERE id = %s', (status, todo_id))
    conn.commit()
    cursor.close()
    conn.close()

def delete_todo(todo_id):
    conn = connect_db()
    cursor = conn.cursor()
    cursor.execute('DELETE FROM todos WHERE id = %s', (todo_id,))
    conn.commit()
    cursor.close()
    conn.close()

def fibonacci_iterative(n):
    fib_sequence = [0, 1]
    for i in range(2, n):
        next_value = fib_sequence[-1] + fib_sequence[-2]
        fib_sequence.append(next_value)
    return fib_sequence

def main():
    create_todo_table()
    
    while True:
        print("1. Generate Fibonacci Series")
        print("2. Add Todo")
        print("3. List Todos")
        print("4. Update Todo Status")
        print("5. Delete Todo")
        print("6. Exit")
        choice = input("Enter your choice: ")
        
        if choice == '1':
            n = int(input("Enter the number of Fibonacci numbers to generate: "))
            fib_sequence = fibonacci_iterative(n)
            print(fib_sequence)
        elif choice == '2':
            task = input("Enter the task: ")
            add_todo(task)
        elif choice == '3':
            todos = get_todos()
            for todo in todos:
                print(todo)
        elif choice == '4':
            todo_id = int(input("Enter the todo ID to update: "))
            status = input("Enter the new status (True/False): ") == 'True'
            update_todo_status(todo_id, status)
        elif choice == '5':
            todo_id = int(input("Enter the todo ID to delete: "))
            delete_todo(todo_id)
        elif choice == '6':
            break

if __name__ == "__main__":
    main()
